import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const ESP32HubApp());

class ESP32HubApp extends StatelessWidget {
  const ESP32HubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ESP32 Sensor Hub',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D1117),
        useMaterial3: true,
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── Change this to your ESP32 IP ──
  final TextEditingController _ipController =
      TextEditingController(text: '192.168.1.100');
  String _esp32IP = '192.168.1.100';

  // Sensor data
  String temp = '--';
  String hum = '--';
  String gas = '--';
  String object = '--';

  // System data
  String wifi = '--';
  String ssid = '--';
  String ip = '--';
  String rssi = '--';
  String uptime = '--';
  String heap = '--';

  // Status
  bool _isConnected = false;
  bool _isLoading = false;
  bool _hasError = false;
  String _statusMsg = 'Enter IP and press Connect';

  Timer? _timer;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _ipController.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  // ── Fetch from /api ──
  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });
    try {
      final uri = Uri.parse('http://$_esp32IP/api');
      final res = await http.get(uri).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        setState(() {
          temp = '${d['temp']} °C';
          hum = '${d['hum']} %';
          gas = '${d['gas']} %';
          object = '${d['object']}';
          wifi = '${d['wifi']}';
          ssid = '${d['ssid']}';
          ip = '${d['ip']}';
          rssi = '${d['rssi']} dBm';
          uptime = '${((d['uptime'] as int) / 60).floor()} min';
          heap = '${((d['heap'] as int) / 1024).floor()} KB';
          _isConnected = true;
          _statusMsg = 'Live — updates every 2s';
          _hasError = false;
        });
      } else {
        _setError('Error ${res.statusCode}');
      }
    } on TimeoutException {
      _setError('Timeout — same WiFi?');
    } catch (_) {
      _setError('Cannot reach ESP32. Check IP.');
    }
    setState(() => _isLoading = false);
  }

  void _setError(String m) => setState(() {
        _hasError = true;
        _statusMsg = m;
        _isConnected = false;
      });

  void _connect() {
    setState(() => _esp32IP = _ipController.text.trim());
    _fetchData();
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _fetchData());
  }

  void _disconnect() {
    _timer?.cancel();
    setState(() {
      _isConnected = false;
      _statusMsg = 'Disconnected';
      temp = '--';
      hum = '--';
      gas = '--';
      object = '--';
      wifi = '--';
      ssid = '--';
      ip = '--';
      rssi = '--';
      uptime = '--';
      heap = '--';
    });
  }

  Color _objectColor() =>
      object == 'DETECTED' ? const Color(0xFFFF3B5C) : const Color(0xFF26D782);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Header ──
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0xFF3B82F6).withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text('📡', style: TextStyle(fontSize: 26)),
                    ),
                    const SizedBox(width: 14),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('ESP32 SENSOR HUB',
                            style: TextStyle(
                                color: Color(0xFF3B82F6),
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2)),
                        Text('HTTP • Same WiFi',
                            style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.35),
                                fontSize: 11,
                                letterSpacing: 1)),
                      ],
                    ),
                    const Spacer(),
                    // Live dot
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color:
                            _isConnected ? const Color(0xFF26D782) : Colors.red,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: (_isConnected
                                    ? const Color(0xFF26D782)
                                    : Colors.red)
                                .withValues(alpha: 0.6),
                            blurRadius: 8,
                          )
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                // ── IP Box ──
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF161B22),
                    borderRadius: BorderRadius.circular(16),
                    border:
                        Border.all(color: Colors.white.withValues(alpha: 0.07)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ESP32 IP ADDRESS',
                          style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.35),
                              fontSize: 10,
                              letterSpacing: 2,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _ipController,
                        style:
                            const TextStyle(color: Colors.white, fontSize: 15),
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: '192.168.1.XXX',
                          hintStyle: TextStyle(
                              color: Colors.white.withValues(alpha: 0.2)),
                          prefixText: 'http://',
                          prefixStyle: TextStyle(
                              color: const Color(0xFF3B82F6)
                                  .withValues(alpha: 0.8),
                              fontSize: 13),
                          suffixText: '/api',
                          suffixStyle: TextStyle(
                              color: Colors.white.withValues(alpha: 0.3),
                              fontSize: 12),
                          border: InputBorder.none,
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: _isConnected ? _disconnect : _connect,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          decoration: BoxDecoration(
                            color: _isConnected
                                ? Colors.red.withValues(alpha: 0.15)
                                : const Color(0xFF3B82F6),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(
                            child: _isLoading
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2, color: Colors.white))
                                : Text(_isConnected ? 'DISCONNECT' : 'CONNECT',
                                    style: TextStyle(
                                        color: _isConnected
                                            ? Colors.red
                                            : Colors.white,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2,
                                        fontSize: 13)),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(children: [
                        Icon(
                            _hasError
                                ? Icons.error_outline
                                : Icons.info_outline,
                            size: 13,
                            color: _hasError
                                ? Colors.red.withValues(alpha: 0.7)
                                : Colors.white.withValues(alpha: 0.28)),
                        const SizedBox(width: 6),
                        Expanded(
                            child: Text(_statusMsg,
                                style: TextStyle(
                                    fontSize: 11,
                                    color: _hasError
                                        ? Colors.red.withValues(alpha: 0.8)
                                        : Colors.white
                                            .withValues(alpha: 0.35)))),
                      ]),
                    ],
                  ),
                ),

                const SizedBox(height: 22),

                // ── Section: Sensors ──
                _sectionLabel('🌿 ENVIRONMENT SENSORS'),
                const SizedBox(height: 10),

                Row(children: [
                  Expanded(
                      child: _Card(
                          emoji: '🌡️',
                          label: 'TEMPERATURE',
                          value: temp,
                          color: const Color(0xFFFF6B35))),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _Card(
                          emoji: '💧',
                          label: 'HUMIDITY',
                          value: hum,
                          color: const Color(0xFF3B82F6))),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                      child: _Card(
                          emoji: '💨',
                          label: 'GAS LEVEL',
                          value: gas,
                          color: const Color(0xFFFFC107))),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _Card(
                    emoji: object == 'DETECTED' ? '🔴' : '🟢',
                    label: 'OBJECT (IR)',
                    value: object,
                    color: _objectColor(),
                  )),
                ]),

                const SizedBox(height: 22),

                // ── Section: System ──
                _sectionLabel('⚙️ SYSTEM DIAGNOSTICS'),
                const SizedBox(height: 10),

                Row(children: [
                  Expanded(
                      child: _Card(
                          emoji: '📡',
                          label: 'WIFI STATUS',
                          value: wifi,
                          color: const Color(0xFF8B5CF6),
                          dark: true)),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _Card(
                          emoji: '🏷️',
                          label: 'SSID',
                          value: ssid,
                          color: const Color(0xFF8B5CF6),
                          dark: true)),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                      child: _Card(
                          emoji: '🌐',
                          label: 'IP ADDRESS',
                          value: ip,
                          color: const Color(0xFF8B5CF6),
                          dark: true)),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _Card(
                          emoji: '📶',
                          label: 'SIGNAL',
                          value: rssi,
                          color: const Color(0xFF8B5CF6),
                          dark: true)),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                      child: _Card(
                          emoji: '⏱️',
                          label: 'UPTIME',
                          value: uptime,
                          color: const Color(0xFF8B5CF6),
                          dark: true)),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _Card(
                          emoji: '💾',
                          label: 'FREE HEAP',
                          value: heap,
                          color: const Color(0xFF8B5CF6),
                          dark: true)),
                ]),

                const SizedBox(height: 22),

                // ── Help box ──
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.03),
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: Colors.white.withValues(alpha: 0.06)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('HOW TO FIND ESP32 IP',
                          style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.3),
                              fontSize: 10,
                              letterSpacing: 2,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      _step('1', 'Upload esp32 code in Arduino IDE'),
                      _step('2', 'Open Serial Monitor (115200 baud)'),
                      _step('3', 'Look for  "IP Address: 192.168.x.x"'),
                      _step('4', 'Type that IP above and press CONNECT'),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(text,
      style: TextStyle(
          color: Colors.white.withValues(alpha: 0.4),
          fontSize: 11,
          letterSpacing: 2,
          fontWeight: FontWeight.bold));

  Widget _step(String n, String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
                color: const Color(0xFF3B82F6).withValues(alpha: 0.15),
                shape: BoxShape.circle),
            child: Center(
                child: Text(n,
                    style: const TextStyle(
                        color: Color(0xFF3B82F6),
                        fontSize: 10,
                        fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 8),
          Expanded(
              child: Text(t,
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.5),
                      fontSize: 12))),
        ]),
      );
}

// ── Card Widget ──
class _Card extends StatelessWidget {
  final String emoji, label, value;
  final Color color;
  final bool dark;
  const _Card(
      {required this.emoji,
      required this.label,
      required this.value,
      required this.color,
      this.dark = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF1C2333) : const Color(0xFF161B22),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: color.withValues(alpha: value == '--' ? 0.08 : 0.25),
            width: 1.4),
        boxShadow: value == '--'
            ? []
            : [BoxShadow(color: color.withValues(alpha: 0.07), blurRadius: 14)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              color: value == '--' ? Colors.white24 : Colors.white,
              fontSize: value.length > 10 ? 13 : 20,
              fontWeight: FontWeight.w800,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          Text(label,
              style: TextStyle(
                  color: color.withValues(alpha: 0.7),
                  fontSize: 9,
                  letterSpacing: 1.5,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
